<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$module_name = 'deliveries';
$viewdefs[$module_name]['EditView'] = array(
	'templateMeta' => array(
		'maxColumns' => '2',
		'form' => array (
			'buttons' => 
			array (
				0 => 'SAVE',
				1 => 'CANCEL',
				2 => array (
				'customCode' => '',
				),
			
			),
		),
		'widths' => array(
		array('label' => '10', 'field' => '30'),
		array('label' => '10', 'field' => '30')
		),
	),
	'panels' =>array (
		array (
			array (
				'name' => 'courier',
				'label' => 'LBL_COURIER',
			),
			array (
				'name' => 'awb',
				'label' => 'LBL_AWB',
			),
		),
		array (
			'location_from',
			'location_to'
		),
		array (
			'date_sent',
			'date_received'
		),
		array (
			'content',
			'comment'
		),

	)
);

?>