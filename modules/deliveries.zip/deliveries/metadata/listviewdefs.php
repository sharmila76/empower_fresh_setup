<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$listViewDefs ['deliveries'] = array (
	'courier' => array (
		'default' => true,
		'label' => 'LBL_COURIER',
		'width' => '10%',
	),
	'awb' => array (
		'default' => true,
		'label' => 'LBL_AWB',
		'width' => '10%',
	),
	'location_from' => array (
		'default' => true,
		'label' => 'LBL_FROM',
		'width' => '10%',
	),
	'location_to' => array (
		'default' => true,
		'label' => 'LBL_TO',
		'width' => '10%',
	),
	'date_sent' => array (
		'default' => true,
		'label' => 'LBL_DATE_SENT',
		'width' => '10%',
	),
	'date_received' => array (
		'default' => true,
		'label' => 'LBL_DATE_RECEIVED',
		'width' => '10%',
	),
	'content' => array (
		'default' => true,
		'label' => 'LBL_CONTENT',
		'width' => '40%',
	),
);


?>