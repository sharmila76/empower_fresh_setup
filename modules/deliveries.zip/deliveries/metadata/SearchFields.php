<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$searchFields['deliveries'] = array (
	'courier' => array (
		'query_type' => 'default',
	),
	'awb' => array (
		'query_type' => 'default',
	),
	'location_from' => array (
		'query_type' => 'default',
	),
	'location_to' => array (
		'query_type' => 'default',
	),
	'content' => array (
		'query_type' => 'default',
	),
	'comment' => array (
		'query_type' => 'default',
	),
);
?>