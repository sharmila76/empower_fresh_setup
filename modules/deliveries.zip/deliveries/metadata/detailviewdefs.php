<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$module_name = 'deliveries';
$viewdefs[$module_name]['DetailView'] = array(
	'templateMeta' => array(
		'maxColumns' => '2',
		'form' => array (
			'buttons' => 
			array (
				0 => 'EDIT',
				1 => 'DUPLICATE',
				2 => 'DELETE',
				3 => array (
				'customCode' => '',
				),
			
			),
		),
		'widths' => array(
		array('label' => '10', 'field' => '30'),
		array('label' => '10', 'field' => '30')
		),
	),
	'panels' =>array (
		array (
			array (
				'name' => 'courier',
				'label' => 'LBL_COURIER',
			),
			array (
				'name' => 'awb',
				'label' => 'LBL_AWB',
			),
		),
		array (
			'location_from',
			'location_to'
		),
		array (
			'date_sent',
			'date_received'
		),
		array (
			'content',
			'comment'
		),

	)
);

?>