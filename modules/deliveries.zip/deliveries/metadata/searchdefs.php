<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
$searchdefs ['deliveries'] = array (
	'layout' => array (
		'basic_search' => array (
			
			'awb' => array (
				'name' => 'courier',
				'default' => false,
				'width' => '10%',
				'displayParams'=>array(size=>2),
			),
			'location_from' => array (
				'name' => 'location_from',
				'default' => false,
				'width' => '10%',
				'displayParams'=>array(size=>2),
			),
			
			'content' => array (
				'name' => 'content',
				'type' => 'text',
				'default' => false,
				'width' => '10%',
				'displayParams'=>array('rows'=>1,'cols'=>50)
			),
		),
		'advanced_search' => array (
			'courier' => array (
				'name' => 'courier',
				'default' => true,
				'width' => '10%',
			),
			'awb' => array (
				'name' => 'awb',
				'default' => true,
				'width' => '10%',
			),
			'location_from' => array (
				'name' => 'location_from',
				'default' => true,
				'width' => '10%',
			),
			'location_to' => array (
				'name' => 'location_to',
				'default' => true,
				'width' => '10%',
			),
			'content' => array (
				'name' => 'content',
				'default' => true,
				'width' => '10%',
			),
		),
	),
	'templateMeta' => array (
		'maxColumns' => '3',
		'maxColumnsBasic' => '4',
		'widths' => array (
			'label' => '10',
			'field' => '30',
		),
	),
);
?>


