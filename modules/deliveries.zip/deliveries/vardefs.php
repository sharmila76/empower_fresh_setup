<?php

$dictionary['delivery']['table']= 'deliveries';
$dictionary['delivery']['audited']= true;
$dictionary['delivery']['fields']= array(
	'courier' => array (
		'name' => 'courier',
		'vname' => 'LBL_COURIER',
		'type' => 'enum',
		'dbType' => 'varchar',
		'len' => '255',
		'required' => true,
		'options' => 'deliveries_delivery_courier_dom',
	),
	'awb' => array(
		'name' => 'awb',
		'vname' => 'LBL_AWB',
		'type' => 'varchar',
		'len' => '100',
	),
	'location_from' => array (
		'name' => 'location_from',
		'vname' => 'LBL_FROM',
		'type' => 'enum',
		'dbType' => 'varchar',
		'len' => '255',
		'required' => true,
		'options' => 'deliveries_delivery_from_dom',
	),
	'location_to' => array (
		'name' => 'location_to',
		'vname' => 'LBL_TO',
		'type' => 'enum',
		'dbType' => 'varchar',
		'len' => '255',
		'required' => true,
		'options' => 'deliveries_delivery_to_dom',
	),
	'date_sent' => array (
		'name' => 'date_sent',
		'vname' => 'LBL_DATE_SENT',
		'type' => 'date',
		'required' => false,
		'display_default' => 'now',
	),
	'date_received' => array (
		'name' => 'date_received',
		'vname' => 'LBL_DATE_RECEIVED',
		'type' => 'date',
		'required' => false,
		'display_default' => 'now',
	),
	'content' => array(
		'name' => 'content',
		'vname' => 'LBL_CONTENT',
		'type' => 'text',
		'required' => true,
		'importable' => 'required',
		'unified_search' => true,
		'full_text_search' => array('boost' => 3),
	),
	'comment' => array(
		'name' => 'comment',
		'vname' => 'LBL_COMMENT',
		'type' => 'text',
	),
);

	
if (!class_exists('VardefManager')){
        require_once('include/SugarObjects/VardefManager.php');
}
VardefManager::createVardef('deliveries','delivery', array('basic','assignable'));

?>