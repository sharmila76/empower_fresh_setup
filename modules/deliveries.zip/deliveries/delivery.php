<?PHP

function refine_awb($value){
	$value= str_replace(' ','',$value);
	$value= str_replace('-','',$value);
	return strtoupper($value);
}

class delivery extends Basic {
	var $new_schema = true;	//required
	var $module_dir = 'deliveries';	//required
	var $object_name = 'delivery';	//required
	var $table_name = 'deliveries';	//required
	var $importable = true;	//required
	var $disable_row_level_security = true ; 	//required 
		// to ensure that modules created and deployed under CE will continue to function under team security if the instance is upgraded to PRO

	public function __construct(){
		parent::Basic();
	}
	
	public function bean_implements($interface){
		switch($interface){
			case 'ACL': return true;
		}
		return false;
	}
	
	public function save($check_notify = FALSE){
		$this->awb= refine_awb($this->awb);
		parent::save($check_notify);
	}
}
?>