<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


require_once('include/MVC/View/views/view.edit.php');

class DeliveryViewEdit extends ViewEdit{
 	function DeliveryViewEdit(){
 		parent::ViewEdit();
 	}
 	function preDisplay(){
		parent::preDisplay();
		
 	}
}

?>