<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point'); 

global $mod_strings, $app_strings, $sugar_config;

		
if(ACLController::checkAccess('deliveries', 'edit', true))$module_menu[]=Array("index.php?module=deliveries&action=EditView&return_module=deliveries&return_action=index", $mod_strings['LNK_NEW_DELIVERY'],"CreateAccounts", 'deliveries');

if(ACLController::checkAccess('deliveries', 'list', true))$module_menu[]=Array("index.php?module=deliveries&action=index&return_module=deliveries&return_action=DetailView", $mod_strings['LNK_DELIVERY_LIST'],"Accounts", 'deliveries');
if(ACLController::checkAccess('deliveries', 'import', true))$module_menu[]=Array("index.php?module=Import&action=Step1&import_module=deliveries&return_module=deliveries&return_action=index", $mod_strings['LNK_IMPORT_DELIVERY'],"Import", 'deliveries');
?>