<?php

$mod_strings = array (
  'LBL_COURIER' => 'Courier',
  'LBL_AWB' => 'AWB',
  'LBL_FROM' => 'From',
  'LBL_TO' => 'To',
  'LBL_DATE_SENT' => 'Date Sent',
  'LBL_DATE_RECEIVED' => 'Date Received',
  'LBL_CONTENT' => 'Content',
  'LBL_COMMENT' => 'Comment',
  
  'LNK_NEW_DELIVERY' => 'Create Delivery',
  'LNK_DELIVERY_LIST' => 'View Deliveries',
  'LNK_IMPORT_DELIVERY' => 'Import Deliveries',
  
  
);